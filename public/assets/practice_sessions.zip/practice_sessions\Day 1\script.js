// Show 'Hello' in a popup
alert('Hello');
