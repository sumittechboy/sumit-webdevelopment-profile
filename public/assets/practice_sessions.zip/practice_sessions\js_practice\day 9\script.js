// hoisting in js 

// console.log(a);
// var a = 10;
// console.log(a);


// refrence datatype

// var a = [1,2,3];
// var b = a;
// b.push(4);
// console.log(a);
// console.log(b);


// if (-1){
//     console.log('code run')
// }


for (var i = 25; i<50; i++){
    console.log(i);
}
  