// alternate sum problem

// console.log('Alternate sum')

// const nums = [1,2,3,4,5];

// const alternatingSum = function(nums) {
//   let sum = 0;
//   for (let i = 0; i < nums.length; i++) {
//     sum += (i % 2 === 0) ? nums[i] : -nums[i];
//   }
//   return sum;
// };

// console.log(alternatingSum(nums)); 

var nums = [2,7,11,15];
var target = 9;

var store = [];
for(i = 0; i<nums.length; i++){
    for(j)

}

